package com.pn.cust;

import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest
public class CustomerApplicationTests {

	@Autowired
	CustomerAPI custApi;
	
	@Test
	public void customerAdd_Test() {
		String msg = custApi.createCustomer("VK", "Name1");
		
		System.out.println(msg);
		
		assert(msg.equals("Customer Added Successfully"));
	}
	
	@Test
	public void customerList_Test() {
		List<Customer> list = custApi.availableCustomers();
		
		System.out.println("List size:"+list.size());
		
		assert(list.isEmpty());		
	}
	
	@Test
	public void customerDel_Test() {
		String msg = custApi.deleteCustomer(2);
		
		System.out.println(msg);
		
		assert(msg.equals("Customer Deleted Successfully"));		
	}

}
