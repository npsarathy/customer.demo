package com.pn.cust;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(value = "/customer")
public class CustomerAPI {
	
	private static List<Customer> customers;
	
	/**
	 * List the existing customers
	 * @return
	 */
    @RequestMapping(value = "/list", method = RequestMethod.POST)
    public List<Customer> availableCustomers() {
//    	if(customers == null){
//    		createCustomer("Name", "NewOne");
//    	}
    	return customers;
    }

    /**
     * Add a new customer with the supplied first and last name values
     * @param firstName
     * @param surName
     * @return
     */
    @RequestMapping(value = "/add", method = RequestMethod.POST)
    public String createCustomer(@RequestParam(value = "firstName", required = true) String firstName,
            @RequestParam(value = "surName", required = true) String surName) {
    	try {
    		int ident;
    		if( customers == null) {
    			customers = new ArrayList<Customer>();
    			ident = 1;
    		}
    		else {
    			ident = customers.size()+1;
    		}
			Customer cust = new Customer(ident, firstName, surName);
			customers.add(cust);
			return "Customer Added Successfully";
		} catch (Exception e) {
			return "Error adding customer";
		}
    }

    /**
     * Delete customer by the supplied id.
     * Usage: /customer/delete?id={number}
     * @param id
     * @return
     */
    @RequestMapping(value = "/delete", method = RequestMethod.POST)
    public String deleteCustomer(@RequestParam(value = "id", required = true) int id) {
    	String msg = "Customer not found";
    	for ( Customer cust : customers ) {
    		if ( id == cust.getId() ){
    			customers.remove(cust);
    			msg = "Customer Deleted Successfully";
    		}
    	}
    	return msg;
    }


}
