package com.pn.cust;
/**
 * Customer DataObject
 * @author PARTHASARATHY
 *
 */
public class Customer {
	
	Integer id;
	String firstName;
	String surName;
	
	public Customer() {
		super();
	}
	public Customer(int id, String firstName, String surName) {
		super();
		this.id = id;
		this.firstName = firstName;
		this.surName = surName;
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getSurName() {
		return surName;
	}
	public void setSurName(String surName) {
		this.surName = surName;
	}
}
